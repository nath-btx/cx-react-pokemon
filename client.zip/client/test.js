const knex = require('knex')({
  client :'pg',
connection: {
  host : '127.0.0.1',
  user: 'postgres',
  password: 'trombone',
  database: 'pokemon',
  }
})


let madata

knex('pokemons').select('numero', 'nom')
.then(function (data) {
    madata = data
    console.log(data);
})

console.log(madata);