import './App.css';
import PokemonCard from './casePokemon.js';
const knex = require('knex')({
  client :'pg',
connection: {
  host : '127.0.0.1',
  user: 'postgres',
  password: 'trombone',
  database: 'pokemon',
  }
})

let madata

  knex('pokemons').select('numero', 'nom')
  
  .then(function (data) {
    madata = data
  })



function App() {  
  return (
    <div className="App">
          <PokemonCard 
            name = {madata}
            id = {"001"}
            imgUrl = {"https://assets.pokemon.com/assets/cms2/img/pokedex/detail/001.png"}
          />
      
    </div>
  );
}

export default App;
